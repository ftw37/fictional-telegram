// Exercises the actual player input callback with a simulated XInput provider.
#include "../player.cpp"
static bool fakeConnected=true;
static DWORD fakeSlot=2;
static XINPUT_GAMEPAD fakePad{};
static DWORD WINAPI fakeGetState(DWORD slot,XINPUT_STATE*out){
 if(!fakeConnected||slot!=fakeSlot)return ERROR_DEVICE_NOT_CONNECTED;
 *out={};out->dwPacketNumber=1;out->Gamepad=fakePad;return ERROR_SUCCESS;
}
static void require(bool value,const char*message){if(!value)throw std::runtime_error(message);}
static bool button(unsigned id){return input(0,RETRO_DEVICE_JOYPAD,0,id)!=0;}
static void replayVideo(const void*p,unsigned w,unsigned h,size_t pitch){headless=true;video(p,w,h,pitch);headless=false;}
static size_t replayAudio(const int16_t*p,size_t frames){headless=true;size_t n=audioBatch(p,frames);headless=false;return n;}
static void replaySample(int16_t l,int16_t r){headless=true;audioSample(l,r);headless=false;}
int main(int argc,char**argv){try{
 headless=false;focused=true;gamepadInitialized=true;getPadState=fakeGetState;
 fakePad.wButtons=XINPUT_GAMEPAD_X|XINPUT_GAMEPAD_A|XINPUT_GAMEPAD_B|XINPUT_GAMEPAD_START;
 readGamepad(0);
 require(gamepadConnected&&gamepadSlot==2,"Discovery must handle a controller in any Xbox slot");
 require(button(RETRO_DEVICE_ID_JOYPAD_Y)&&button(RETRO_DEVICE_ID_JOYPAD_B)&&button(RETRO_DEVICE_ID_JOYPAD_A)&&button(RETRO_DEVICE_ID_JOYPAD_START),"Xbox face buttons and Menu must reach the game");
 require(!input(1,RETRO_DEVICE_JOYPAD,0,RETRO_DEVICE_ID_JOYPAD_Y),"Controller must drive player one");
 fakePad={};fakePad.sThumbLX=7849;fakePad.sThumbLY=-7849;fakePad.bLeftTrigger=30;readGamepad(1);
 require(gamepadMask==0,"Stick drift and unpressed triggers must stay neutral");
 fakePad.sThumbLX=32767;fakePad.sThumbLY=-32768;readGamepad(2);
 require(button(RETRO_DEVICE_ID_JOYPAD_RIGHT)&&button(RETRO_DEVICE_ID_JOYPAD_DOWN),"Analog diagonals must reach the D-pad");
 fakePad={};fakePad.wButtons=XINPUT_GAMEPAD_DPAD_UP|XINPUT_GAMEPAD_DPAD_LEFT;readGamepad(3);
 require(button(RETRO_DEVICE_ID_JOYPAD_UP)&&button(RETRO_DEVICE_ID_JOYPAD_LEFT),"Digital diagonals must work");
 fakePad={};fakePad.wButtons=XINPUT_GAMEPAD_LEFT_SHOULDER|XINPUT_GAMEPAD_RIGHT_SHOULDER;readGamepad(4);
 require(button(RETRO_DEVICE_ID_JOYPAD_Y)&&button(RETRO_DEVICE_ID_JOYPAD_A),"Shoulders must act as Genesis A/C");
 fakePad={};fakePad.bLeftTrigger=31;fakePad.bRightTrigger=255;readGamepad(5);
 require(button(RETRO_DEVICE_ID_JOYPAD_Y)&&button(RETRO_DEVICE_ID_JOYPAD_A),"Trigger aliases must work");
 fakePad={};fakePad.wButtons=XINPUT_GAMEPAD_A;heldKeys['C']=true;readGamepad(6);
 require(button(RETRO_DEVICE_ID_JOYPAD_B)&&button(RETRO_DEVICE_ID_JOYPAD_A),"Keyboard and pad must work together");
 fakeConnected=false;readGamepad(7);
 require(!gamepadConnected&&!button(RETRO_DEVICE_ID_JOYPAD_B)&&button(RETRO_DEVICE_ID_JOYPAD_A),"Unplug must release pad buttons while leaving keyboard working");
 heldKeys.fill(false);fakeConnected=true;fakeSlot=3;fakePad={};fakePad.wButtons=XINPUT_GAMEPAD_START;readGamepad(507);
 require(gamepadConnected&&gamepadSlot==3&&button(RETRO_DEVICE_ID_JOYPAD_START),"Reconnect in a different Xbox slot must work");
 focused=false;require(!button(RETRO_DEVICE_ID_JOYPAD_START),"Unfocused player must ignore gamepad input");focused=true;
 getPadState=nullptr;readGamepad(508);heldKeys['Z']=true;
 require(!gamepadConnected&&gamepadMask==0&&button(RETRO_DEVICE_ID_JOYPAD_Y),"Keyboard must work without XInput");
 gamepadInitialized=false;initGamepad();require(getPadState!=nullptr,"System XInput DLL must load without bundled dependencies");
 if(gamepadLibrary){FreeLibrary(gamepadLibrary);gamepadLibrary=nullptr;}
 if(argc>1){
  baseDir=argv[1];std::string path=baseDir+"/game.md";checkRom(path);
  core=LoadLibraryA((baseDir+"/devil-native.dll").c_str());require(core!=nullptr,"Game compatibility DLL must load");
  proc<void(*)(retro_environment_t)>("retro_set_environment")(environment);
  proc<void(*)(retro_video_refresh_t)>("retro_set_video_refresh")(replayVideo);
  proc<void(*)(retro_audio_sample_t)>("retro_set_audio_sample")(replaySample);
  proc<void(*)(retro_audio_sample_batch_t)>("retro_set_audio_sample_batch")(replayAudio);
  proc<void(*)(retro_input_poll_t)>("retro_set_input_poll")(pollInput);
  proc<void(*)(retro_input_state_t)>("retro_set_input_state")(input);
  initCore=proc<void(*)()>("retro_init");runCore=proc<void(*)()>("retro_run");unloadCore=proc<void(*)()>("retro_unload_game");deinitCore=proc<void(*)()>("retro_deinit");
  loadGame=proc<bool(*)(const retro_game_info*)>("retro_load_game");nativeCount=proc<uint64_t(*)()>("retro_native_instructions");
  heldKeys.fill(false);getPadState=fakeGetState;gamepadInitialized=true;gamepadSlot=XUSER_MAX_COUNT;nextGamepadScan=0;fakeConnected=true;fakeSlot=0;
  initCore();retro_game_info game={path.c_str(),nullptr,0,nullptr};require(loadGame(&game),"Game must load for controller replay");
  for(frameNumber=0;frameNumber<1800;++frameNumber){
   fakePad={};
   if((frameNumber>=300&&frameNumber<304)||(frameNumber>=420&&frameNumber<424))fakePad.wButtons|=XINPUT_GAMEPAD_START;
   if(frameNumber>480){if(frameNumber%180<60)fakePad.wButtons|=XINPUT_GAMEPAD_A;if(frameNumber%60<30)fakePad.wButtons|=XINPUT_GAMEPAD_X;if(frameNumber%80<30)fakePad.wButtons|=XINPUT_GAMEPAD_B;}
   runCore();
  }
  require(videoHash==0xb0b1283c528accecULL&&audioHash==0x35754a014bf0e099ULL,"Controller-driven game replay must match reference video/audio");
  require(nativeCount()==20712440ULL,"Controller replay must execute the reference instruction sequence");
  unloadCore();deinitCore();FreeLibrary(core);
 }
 std::ofstream report("gamepad-test.txt");report<<"PASS: buttons, shoulders, triggers, stick deadzone, diagonals, mixed keyboard/pad, disconnect, reconnect, focus, system DLL loading, and (when release path supplied) 1800-frame controller-driven game replay\n";
 return 0;
 }catch(const std::exception&e){std::ofstream report("gamepad-test.txt");report<<"FAIL: "<<e.what()<<'\n';return 1;}}
